import pandas as pd
from airline_delay.schemas import ProjectConfig, Environment
from airline_delay.settings import LOCAL_DATA_LOCATION
from sklearn.model_selection import train_test_split
from pyspark.sql import SparkSession

class DataPipeline:

    def __init__(self, config: ProjectConfig, spark: SparkSession):
        self._config = config
        self._spark = spark

    def extract_data(self) -> pd.DataFrame:
        if self._config.env == Environment.DATABRICKS:
            return self._extract_data_from_volume()
        return self._extract_data_local()
    
    def process_data(self, df: pd.DataFrame) -> pd.DataFrame:
        df = self._cast_type_to_categorical(df)
        df = self._cast_type_to_numerical(df)
        return df
    
    def create_splits(self, df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
        train_df, test_df = train_test_split(df, train_size=0.8, test_size=0.2)
        return train_df, test_df

    def save_data(self, df: pd.DataFrame, target_table_name: str) -> pd.DataFrame:
        sdf = self._spark.createDataFrame(df)
        sdf.write.mode("overwrite").saveAsTable(f"{self.volume_path}.{target_table_name}")

    def _extract_data_from_volume(self) -> pd.DataFrame:
        return self._spark.table(f"{self.volume_path}.data").toPandas()

    def _extract_data_local(self) -> pd.DataFrame:
        return pd.read_csv(LOCAL_DATA_LOCATION, index_col=0)

    def _cast_type_to_numerical(self, df: pd.DataFrame) -> pd.DataFrame:
        for numerical_column in self._config.numerical_features:
            df[numerical_column] = pd.to_numeric(df[numerical_column], errors="coerce").astype("float")
        return df

    def _cast_type_to_categorical(self, df: pd.DataFrame) -> pd.DataFrame:
        for categorical_column in self._config.categorical_features:
            df[categorical_column] = df[categorical_column].astype("category")
        return df

    @property
    def volume_path(self) -> str:
        return f"{self._config.catalog_name}.{self._config.schema_name}"